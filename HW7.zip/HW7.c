#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct 
{
    char word[30];
}zaban;

int main()
{
    int number;
    printf("enter a number \n");
    scanf("%d",&number);
    zaban zaban1[number];
    zaban zaban2[number];

    for(int i=0; i<number; i++)
    {
        scanf("%s %c",zaban1[i].word,&zaban2[i].word[0]);
        scanf("%s", zaban2[i].word + 1);
        printf("\n");
    }

    getchar();
    char sen[80];
    fgets(sen,80,stdin);
    
    if(zaban1[0].word[0] >= 'A' && zaban1[0].word[0] <= 'Z')
    {
        for(size_t i=0;sen[i]; i++)
        {
            sen[i] = toupper(sen[i]);
        }     
    }
    else
    {
        for(size_t i=0;sen[i]; i++)
        {
            sen[i] = tolower(sen[i]);
        }
    }

    char* token=strtok(sen," ");
    zaban save[155];

    int i=0;
    while(token != NULL)
    {
        strcpy(save[i].word,token);
        token=strtok(NULL," ");
        i++;
    }

    for(int j=0;j<i;j++)
    {
        for(int k=0; k<number; k++)
        {
            if( strcmp( save[j].word ,zaban1[k].word) == 0)
            {
                if( strlen(zaban2[k].word) < strlen(zaban1[k].word))
                {
                    strcpy(save[j].word,zaban2[k].word);
                }
            }
        }
    }
    for(int k=0;k<i;k++)
    {
        printf("%s ",save[k].word);
    }
}